<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');
* {]
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 0;
    font-family: 'Poppins', sans-serif;
    font-size: 20px;
}


#navigation {
    width: 100%;
    height: 100px;
}

#logo {
    width: 30%;
    height: 100px;
    background-image: url(SRKR.png);
    background-position: center;
    background-repeat: no-repeat;
    float: left;
}

#navbar {
    width: 70%;
    height: 100px;
    float: right;
    font-size: 25px;
}

ul {
    list-style-type: none;
}

li {
    float: right;
    width: 240px;
    height: 60px;
    color: black;
}

li a {
    text-decoration: none;
    color: black;
    text-align: center;
}

li a:hover,
a:active {
    background-color: rgb(76, 3, 144);
    color: white;
    border-radius: 4px;
}

li a:link,
a:visited {
    color: rgb(60, 18, 92);
    padding: 14px 25px;
    display: inline-block;
}
#one
{
    width:100%;
    height:10px;
    border-bottom:10px solid rgb(76, 3, 144);
}
.container {
	display: flex;
	flex-wrap: wrap;
	justify-content: center;
	align-items: center;
	margin: 20px;
    
}
.box {
	background-color: #f1f1f1;
	color: #333;
	padding: 20px;
	margin: 20px;
	width: 300px;
	text-align: center;
	box-shadow: 10px 9px 5px rgba(0, 0, 0, 0.3);
	border-radius: 5px;
	transition: box-shadow 0.3s ease-in-out;
    border-radius:  2rem 2rem 2rem 2em;
}

.box:hover {
	box-shadow: 0 0 10px rgba(0, 0, 0, 0.4);
}
h1
{
    margin:20px;
}
</style>
</head>
<body>
    <div id="navigation">
        <div id="logo"></div>
        <div id="navbar">
            <div>
                <ul>
                    <li><a href="addbook.php">ADD BOOK</a></li>
                    <li><a href="updatebook.html">UPDATE BOOK</a></li>
                    <li><a href="issuebook.html">ISSUE BOOK</a></li>
                    <li><a href="update_profile.php">MyProfile</a></li>
                    <!-- <li><a href="#" onclick="window.open('lgn.php', 'Login', 'width=100,height=100');">Login</a></li>-->
                </ul>
            </div>
        </div>
    </div>
    <div id="one"></div>
    <h1>Dashboard</h1>
    <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "books";
    
        $conn = mysqli_connect($servername, $username, $password, $dbname);
    ?>
    </div>
    <div class="container">
		<div class="box">
            <i class="fa fa-book fa-5x"></i>
			<h2> Art</h2>
            <?php
                    $category=" Art and Humanities";
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        $query="select count(*) as count from addbook where category='$category'";
                        $result = mysqli_query($conn, $query);
                        $count = mysqli_fetch_assoc($result)['count'];
                        ?>
            <p><?php echo $count?></p>
		</div>
		<div class="box">
        <i class="fa fa-book fa-5x"></i>
			<h2>Academic</h2>
            <?php
                    $category="Career Development";
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        $query="select count(*) as count from addbook where category='$category'";
                        $result = mysqli_query($conn, $query);
                        $count = mysqli_fetch_assoc($result)['count'];
                        ?>
                        <p><?php echo $count?></p>
                            <?php
                    ?>
		</div>
		<div class="box">
        <i class="fa fa-book fa-5x"></i>
        <h2>Education</h2>    
            <?php
                    $category="Leisure";
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        $query="select count(*) as count from addbook where category='$category'";
                        $result = mysqli_query($conn, $query);
                        $count = mysqli_fetch_assoc($result)['count'];
                        ?>
                        <p><?php echo $count?></p>
                            <?php
                    ?>
		</div>
		<div class="box">
        <i class="fa fa-book fa-5x"></i>
			<h2>History</h2>
            <?php
                    $category="History";
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        $query="select count(*) as count from addbook where category='$category'";
                        $result = mysqli_query($conn, $query);
                        $count = mysqli_fetch_assoc($result)['count'];
                        ?>
                        <p><?php echo $count?></p>
                            <?php
                    ?>
		</div>
        <div class="box">
        <i class="fa fa-book fa-5x"></i>
        <h2>Total books</h2>
                <?php
                        $conn = mysqli_connect($servername, $username, $password, $dbname);
                        $query="select count(*) as count from addbook";
                        $result = mysqli_query($conn, $query);
                        $count = mysqli_fetch_assoc($result)['count'];
                        ?>
                        <p><?php echo $count?></p>
                            <?php
                    ?>
</div>
</body>
</html>