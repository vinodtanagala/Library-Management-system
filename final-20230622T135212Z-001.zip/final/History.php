<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');
* {
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    text-decoration: none;
}
th{
  padding:10px 30px 20px 10px
}
table{
  width:80%;
  height:auto;
  text-align:center;
  background-color:white;

}
tr:nth-child(odd) {background-color: #f2f2f2;}
td{
  text-align:center;
  color:blue;
  padding:10px 20px 20px;
}
th,td{
border-bottom: 1px solid #ddd;
}
h1{
  text-align:center;
}
body{
  background: linear-gradient(to right, #0f2027, #203a43, #2c5364);
}

        </style>
</head>
<body>
    <h1>Books History</h1>
    <br>
    <br>
</body>
</html>
<?php
$servername = "localhost";
$username = "root";
    $password = "";
    $dbname = "books";
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    ?>
    <center><table>
  <tr>
        <th>Book_ID</th>
        <th>Book_Name</th>
        <th>Book Author</th>
        <th>Taken Date</th>
        <th>Return Date</th>
  </tr>
    <?php
   $query="select * from history";
   $query_run=mysqli_query($conn,$query);
    if(mysqli_num_rows($query_run)>0)
    {
   ?>
   <?php
        while($row=mysqli_fetch_assoc($query_run))
       {
        ?>
        <tr>
            <td><?php echo $row['book_id']?></td>
            <td><?php echo $row['book_name']?></td>
            <td><?php echo $row['book_author']?></td>
            <td><?php echo $row['issue_date']?></td>
            <td><?php echo $row['status']?></td>
        </tr>
           <?php
       }
   ?>
   </table></center>
</div>
   <?php
}
else{
   echo "No record found";
}?>
