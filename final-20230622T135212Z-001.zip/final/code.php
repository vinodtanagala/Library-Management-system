<?php
// Connect to the database
/*
// Insert data into the database

   $bookid = $_POST['bookid'];
   // $product_type = $_POST['product_type'];
    //$cost_of_product = $_POST['cost_of_product'];
    //$name_of_seller = $_POST['name_of_seller'];

    $product_img = $_FILES['product_img']['name'];
   // $product_image_temp = $_FILES['product_img']['tmp_name'];
    $product_image_folder = "upload/";

    // Move uploaded file to destination folder
    if (move_uploaded_file($product_image_temp, $product_image_folder.$product_img)) {
        // File uploaded successfully
        $stmt = $conn->prepare("INSERT INTO book ('bookid','filename') VALUES (?,?)");
        $stmt->bind_param("ss", $bookid,$product_img);

        $stmt->execute();
        echo "Data inserted successfully";
        $stmt->close();
    } else {
        // Failed to upload file
        echo "Error uploading file.";
    }

$conn->close();
*/

    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "books";

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if (!$conn) 
    {
        die("Connection failed: " . mysqli_connect_error());
    }

    $bookname=$_POST['bookname']; 
    $category=$_POST['category']; 
    $bookid=$_POST['bookid']; 
    $bookauthor=$_POST['bookauthor']; 
    $copies=$_POST['copies']; 


	$filename = $_FILES['uploadfile']['name'];
    $filename_temp=$_FILES['uploadfile']['tmp_name'];
	///$tempname = $_FILES["uploadfile"]["tmp_name"];
	$folder = "images/";
	//$db = mysqli_connect("localhost", "root", "", "db");
    if(move_uploaded_file($filename_temp,$folder.$filename))
    {
        //file uploaded
        $stmt=$conn->prepare("insert into addbook VALUES(?,?,?,?,?,?)");
        $stmt->bind_param("ssssss",$bookname,$category,$bookid,$bookauthor,$copies,$filename);
        $stmt->execute();
        echo "Data inserted";
        $stmt->close();
    }else{
    echo "error uploading";
    }
?>